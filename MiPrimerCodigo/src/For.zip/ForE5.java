
public class ForE5 {

	public static void main(String[] args) {

		for (int c = 1; c <= 100; c ++){			
			System.out.print(c+" ");
			if(c % 10 == 0) {
				System.out.println("\t");
			}						
				
		}

	}

}
