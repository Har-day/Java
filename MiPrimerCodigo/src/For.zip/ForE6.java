
public class ForE6 {

	public static void main(String[] args) {

		for(int c = 0; c<= 10; c++){
			for(int n2 = 1; n2 <= 10; n2++){				
				System.out.println( c + " * "+ n2 + " = " + (c*n2));		
				
			}
			System.out.println("");
		}
	}

}
